;216214353
;328381926
.ORIG x4000
Mul
    ST R0, R0_SAVE      ; Save R0 to restore later
    ST R1, R1_SAVE      ; Save R1 to restore later
    ST R7, R7_SAVE      ; Save Return Address (R7)

    AND R2, R2, #0      ; Initialize Result (R2) to 0

    ADD R0, R0, #0      ; Check if R0 is 0
    BRz END_MUL         ; If R0 is 0, Result is 0, Go to End
    ADD R1, R1, #0      ; Check if R1 is 0
    BRz END_MUL         ; If R1 is 0, Result is 0, Go to End

    BRp START_LOOP      ; If R1 (Counter) is positive, skip sign flip

    NOT R1, R1          ; Flip bits of R1
    ADD R1, R1, #1      ; R1 = -R1 (Make counter positive)
    NOT R0, R0          ; Flip bits of R0
    ADD R0, R0, #1      ; R0 = -R0 (Flip number to add to match sign logic)

START_LOOP
    ADD R2, R2, R0      ; Add R0 to Result (R2)
    ADD R1, R1, #-1     ; Decrement Counter (R1)
    BRp START_LOOP      ; Loop while Counter > 0

END_MUL
    LD R0, R0_SAVE      ; Restore original R0
    LD R1, R1_SAVE      ; Restore original R1
    LD R7, R7_SAVE      ; Restore original R7
    RET                 ; Return from subroutine

; Subroutine Data
R0_SAVE .FILL #0        ; Storage for saved R0
R1_SAVE .FILL #0        ; Storage for saved R1
R7_SAVE .FILL #0        ; Storage for saved R7

.END