;216214353
;328281926
.ORIG x41F4
GetNum
    ; --- Save registers (Backup) ---
    ST R0, SaveR0
    ST R1, SaveR1
    ST R3, SaveR3
    ST R4, SaveR4
    ST R5, SaveR5
    ST R6, SaveR6
    ST R7, SaveR7

    ; --- Print start message ---
    LEA R0, STR_START
    PUTS

RESET_INPUT
    ; --- Reset variables for new input ---
    AND R2, R2, #0      ; R2 = 0 (The constructed number)
    AND R3, R3, #0      ; R3 = 0 (Sign flag: 0=Positive, 1=Negative)
    AND R5, R5, #0      ; R5 = 0 (Digit counter)
    AND R6, R6, #0      ; R6 = 0 (Error Flag: 0=OK, 1=InvalidChar, 2=Overflow)

INPUT_LOOP
    GETC                ; Get character to R0
    OUT                 ; Print character (Echo)

    ; --- Check for ENTER (End of input) ---
    ADD R1, R0, #-10    ; Check if char is ASCII 10 (Enter)
    BRz CHECK_ERRORS    ; If Enter, go to validate input

    ; --- Check for Minus sign ('-') ---
    LD R1, ASCII_MINUS  ; Load '-' value
    ADD R1, R0, R1      ; Compare: Char - '-'
    BRnp CHECK_DIGIT    ; If not minus, skip to digit check

    ; If we are here, the char is minus
    ADD R5, R5, #0      ; Check: Is this the first character?
    BRp SET_ERR_CHAR    ; If R5 > 0, minus appeared inside number -> Mark Error
    ADD R3, R3, #1      ; Set negative flag (R3 = 1)
    ADD R5, R5, #1      ; Increment char counter
    BRnzp INPUT_LOOP    ; Return to loop for next char

CHECK_DIGIT
    ; --- Check if char is a digit (0-9) ---
    LD R1, ASCII_ZERO_NEG ; Load minus '0'
    ADD R1, R0, R1      ; R1 = Char - '0'
    BRn SET_ERR_CHAR    ; If result is negative (< '0') -> Mark Error
   
    ADD R4, R1, #-9     ; Check if > 9
    BRp SET_ERR_CHAR    ; If > 9 -> Mark Error

    ; --- Check for previous errors ---
    ; The character is valid (digit). Now check if we already have an Overflow.
    ; If R6 > 0 (meaning R6=2 for Overflow), skip math but stay in loop.
    ADD R6, R6, #0
    BRp INPUT_LOOP

    ; --- Math Logic (Only runs if R6 == 0) ---
    ; Algorithm: R2 = R2 * 10 + Digit
   
    ADD R4, R2, R2      ; R4 = 2*R2
    BRn CHECK_OVF_NEG   ; If negative -> Potential Overflow
   
    ADD R2, R4, R4      ; R2 = 4*R2 (Temp)
    BRn CHECK_OVF_NEG   ; Check Overflow
   
    ADD R2, R2, R2      ; R2 = 8*R2
    BRn CHECK_OVF_NEG   ; Check Overflow

    ADD R2, R2, R4      ; R2 = 8*R2 + 2*R2 = 10*R2
    BRn CHECK_OVF_NEG   ; Check Overflow

    ; --- Add the new digit ---
    ADD R2, R2, R1      ; R2 = R2 + Digit
    BRn CHECK_OVF_NEG   ; If result becomes negative, potential Overflow

    ; Update char counter and loop back
    ADD R5, R5, #1
    BRnzp INPUT_LOOP

; --- Error Setting Logic (Inside Loop) ---
SET_ERR_CHAR
    ; Priority: Invalid Char overrides Overflow
    AND R6, R6, #0      ; Clear previous error
    ADD R6, R6, #1      ; Set Error Flag to 1 (Invalid Char)
    BRnzp INPUT_LOOP    ; Continue loop to consume rest of line

SET_ERR_OVF
    ; Set Overflow only if no other error exists
    ADD R6, R6, #0     
    BRp INPUT_LOOP      ; If already error (1 or 2), keep it
    ADD R6, R6, #2      ; Set Error Flag to 2 (Overflow)
    BRnzp INPUT_LOOP    ; Continue loop to consume rest of line

; --- Special Overflow Logic  ---
CHECK_OVF_NEG
    LD R4, VAL_MIN_INT  ; Load x8000
    NOT R4, R4
    ADD R4, R4, #1      ; R4 = -x8000 (Two's complement of x8000 is still x8000)
   
    ; Compare current R2 with x8000
    ADD R4, R2, R4      ; Check if R2 == x8000
    BRnp SET_ERR_OVF    ; If negative but not x8000 -> Definite Overflow

    ; If here, Number is exactly 32768 (x8000 in hex).
    ; This is VALID only if Sign Flag (R3) is 1 (Negative).
    
    ADD R3, R3, #0      ; Check R3 value
    BRp VALID_MIN_INT   ; If R3 > 0 (meaning R3=1, Negative), it is VALID.
    
    ; If R3 is 0 (Positive), then 32768 is too big -> Overflow.
    BRnzp SET_ERR_OVF

VALID_MIN_INT
    ; Valid negative limit reached (-32768).
    ADD R5, R5, #1      ; Increment digit counter
    BRnzp INPUT_LOOP


; --- Validation after ENTER is pressed ---
CHECK_ERRORS
    ; Check the Error Flag (R6)
    ADD R6, R6, #-1
    BRz ERROR_CHAR_MSG  ; If R6 was 1 -> Invalid Char Error

    ADD R6, R6, #-1
    BRz ERROR_OVF_MSG   ; If R6 was 2 -> Overflow Error
   
    ; If R6 was 0 (No errors), logic falls through here
   
    ; Check if input was empty (only Enter)
    ADD R5, R5, #0
    BRz RESTORE_REGS    ; Treat empty input as 0

    ; --- Process Sign ---
    ADD R3, R3, #0      ; Check sign flag
    BRz RESTORE_REGS    ; If positive, done

    ; If negative, apply 2's complement on R2
    NOT R2, R2
    ADD R2, R2, #1
    BRnzp RESTORE_REGS

; --- Error Messages ---
ERROR_CHAR_MSG
    LEA R0, STR_ERR_NUM
    PUTS
    BRnzp RESET_INPUT   ; Reset and restart

ERROR_OVF_MSG
    LEA R0, STR_ERR_OVF
    PUTS
    BRnzp RESET_INPUT   ; Reset and restart


RESTORE_REGS
    ; --- Restore registers ---
    LD R0, SaveR0
    LD R1, SaveR1
    LD R3, SaveR3
    LD R4, SaveR4
    LD R5, SaveR5
    LD R6, SaveR6
    LD R7, SaveR7
    RET

; --- Data Area ---
SaveR0 .BLKW 1
SaveR1 .BLKW 1
SaveR3 .BLKW 1
SaveR4 .BLKW 1
SaveR5 .BLKW 1
SaveR6 .BLKW 1
SaveR7 .BLKW 1

ASCII_ZERO_NEG .FILL xFFD0  ; -48 ('0')
ASCII_MINUS    .FILL xFFD3  ; -45 ('-')
VAL_MIN_INT    .FILL x8000  ; 32768 / -32768

STR_START   .STRINGZ "Enter an integer number: "
STR_ERR_NUM .STRINGZ "Error! You did not enter a number. Please enter again: "
STR_ERR_OVF .STRINGZ "Error! Number overflowed! Please enter again: "

.END