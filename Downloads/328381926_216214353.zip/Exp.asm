;216214353
;328381926
.ORIG x40C8

Exp
    ST R0, EXP_R0_SAVE  ; Save R0 to restore later
    ST R1, EXP_R1_SAVE  ; Save R1 to restore later
    ST R3, EXP_R3_SAVE  ; Save R3 to restore later
    ST R4, EXP_R4_SAVE  ; Save R4 to restore later
    ST R5, EXP_R5_SAVE  ; Save R5 to restore later
    ST R6, EXP_R6_SAVE  ; Save R6 to restore later
    ST R7, EXP_R7_SAVE  ; Save Return Address (R7)

    ; Step 1: Check for Illegal Inputs
    
    LD R0, EXP_R0_SAVE  ; Load Base (R0)
    BRn IS_ERROR        ; If Base < 0, Error

    LD R1, EXP_R1_SAVE  ; Load Exponent (R1)
    BRn IS_ERROR        ; If Exponent < 0, Error

    LD R0, EXP_R0_SAVE  ; Reload Base
    BRnp CHECK_ZERO_EXP ; If Base != 0, check Exponent
    LD R1, EXP_R1_SAVE  ; Reload Exponent
    BRz IS_ERROR        ; If Base == 0 AND Exponent == 0, Error

    ; Step 2: Handle Edge Case x^0 = 1

CHECK_ZERO_EXP
    LD R1, EXP_R1_SAVE  ; Reload Exponent
    BRz RET_ONE         ; If Exponent == 0, Result is 1

    ; Step 3: Calculation Loop
    
    AND R4, R4, #0      ; Clear R4
    ADD R4, R4, #1      ; R4 = 1 (Initialize Current Result)
    
    LD R5, EXP_R0_SAVE  ; R5 = Base (Constant for multiplication)
    LD R6, EXP_R1_SAVE  ; R6 = Exponent (Loop Counter)
    
    LD R3, ADDR_MUL     ; Load address of Mul subroutine

EXP_LOOP
    ADD R6, R6, #0      ; Check Loop Counter
    BRz EXP_DONE        ; If Counter is 0, Loop Finished

    ADD R0, R4, #0      ; Argument 1 for Mul: Current Result
    ADD R1, R5, #0      ; Argument 2 for Mul: Base
    
    JSRR R3             ; Call Mul(Result, Base) -> Returns R2

    ADD R4, R2, #0      ; Update Result (R4 = Mul Result)
    ADD R6, R6, #-1     ; Decrement Loop Counter
    BR EXP_LOOP         ; Repeat Loop

EXP_DONE
    ADD R2, R4, #0      ; Move Final Result to R2
    BR FINISH           ; Go to Finish

RET_ONE
    AND R2, R2, #0      ; Clear R2
    ADD R2, R2, #1      ; Set R2 = 1
    BR FINISH           ; Go to Finish

IS_ERROR
    AND R2, R2, #0      ; Clear R2
    ADD R2, R2, #-1     ; Set R2 = -1 (Error Code)
    BR FINISH           ; Go to Finish

FINISH
    LD R0, EXP_R0_SAVE  ; Restore R0
    LD R1, EXP_R1_SAVE  ; Restore R1
    LD R3, EXP_R3_SAVE  ; Restore R3
    LD R4, EXP_R4_SAVE  ; Restore R4
    LD R5, EXP_R5_SAVE  ; Restore R5
    LD R6, EXP_R6_SAVE  ; Restore R6
    LD R7, EXP_R7_SAVE  ; Restore R7
    RET                 ; Return from subroutine

ADDR_MUL    .fill x4000 ; Address of Mul subroutine
EXP_R0_SAVE .fill #0    ; Storage for R0
EXP_R1_SAVE .fill #0    ; Storage for R1
EXP_R3_SAVE .fill #0    ; Storage for R3
EXP_R4_SAVE .fill #0    ; Storage for R4
EXP_R5_SAVE .fill #0    ; Storage for R5
EXP_R6_SAVE .fill #0    ; Storage for R6
EXP_R7_SAVE .fill #0    ; Storage for R7

.END