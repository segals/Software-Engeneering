;328381926
;216214353
.ORIG x4384

Calculator
    ; 1. Save Registers
    ST R0, CALC_SAVE_R0     ; Save first number (a)
    ST R1, CALC_SAVE_R1     ; Save second number (b)
    ST R7, CALC_SAVE_R7     ; Save return address

    ; 2. Ask user for operator
    LEA R0, STR_OP_PROMPT   ; Load prompt string
    PUTS                    ; Print prompt
    GETC                    ; Get character from user (Operator)
    OUT                     ; Echo character to screen
    ST R0, CALC_OP_CHAR     ; Store operator in memory
    
    ; Print a newline
    LD R0, CHAR_NEWLINE
    OUT

    ; 3. Print the Equation: "a op b ="
    
    ; Print 'a' (using PrintNum)
    LD R0, CALC_SAVE_R0     ; Reload 'a'
    LD R6, ADDR_PRINT_NUM   ; Load address of PrintNum
    JSRR R6                 ; Call PrintNum

    ; Print the Operator
    LD R0, CALC_OP_CHAR
    OUT

    ; Print 'b' (using PrintNum)
    LD R0, CALC_SAVE_R1     ; Reload 'b'
    LD R6, ADDR_PRINT_NUM
    JSRR R6

    ; Print " = "
    LEA R0, STR_EQUALS
    PUTS

    ; 4. Decode Operator and Execute
    LD R0, CALC_OP_CHAR     ; Reload operator for comparison

    ; Check: Is it '+'?
    LD R1, ASCII_PLUS_NEG
    ADD R1, R0, R1
    BRz DO_ADD

    ; Check: Is it '-'?
    LD R1, ASCII_MINUS_NEG
    ADD R1, R0, R1
    BRz DO_SUB

    ; Check: Is it '*'?
    LD R1, ASCII_MUL_NEG
    ADD R1, R0, R1
    BRz DO_MUL

    ; Check: Is it '/'?
    LD R1, ASCII_DIV_NEG
    ADD R1, R0, R1
    BRz DO_DIV

    ; Check: Is it '^'?
    LD R1, ASCII_EXP_NEG
    ADD R1, R0, R1
    BRz DO_EXP

    ; If here, operator is invalid. Skip to end
    BR FINISH_CALC

; --- Operation Implementation ---

DO_ADD
    LD R0, CALC_SAVE_R0
    LD R1, CALC_SAVE_R1
    ADD R2, R0, R1          ; R2 = a + b
    BR PRINT_RESULT

DO_SUB
    LD R0, CALC_SAVE_R0
    LD R1, CALC_SAVE_R1
    NOT R1, R1              ; 2's Complement part 1 (Flip bits)
    ADD R1, R1, #1          ; 2's Complement part 2 (Add 1) -> R1 = -b
    ADD R2, R0, R1          ; R2 = a + (-b)
    BR PRINT_RESULT

DO_MUL
    LD R0, CALC_SAVE_R0     ; Argument 1 for Mul
    LD R1, CALC_SAVE_R1     ; Argument 2 for Mul
    LD R6, ADDR_MUL         ; Load address of Mul subroutine
    JSRR R6                 ; Call Mul -> Result in R2
    BR PRINT_RESULT

DO_DIV
    LD R0, CALC_SAVE_R0     ; Argument 1 for Div (Dividend)
    LD R1, CALC_SAVE_R1     ; Argument 2 for Div (Divisor)
    LD R6, ADDR_DIV         ; Load address of Div subroutine
    JSRR R6                 ; Call Div -> Result (Quotient) in R2
    BR PRINT_RESULT

DO_EXP
    LD R0, CALC_SAVE_R0     ; Argument 1 for Exp (Base)
    LD R1, CALC_SAVE_R1     ; Argument 2 for Exp (Exponent)
    LD R6, ADDR_EXP         ; Load address of Exp subroutine
    JSRR R6                 ; Call Exp -> Result in R2
    BR PRINT_RESULT

; 5. Print Final Result
PRINT_RESULT
    ADD R0, R2, #0          ; Move Result (R2) to R0 for printing
    LD R6, ADDR_PRINT_NUM   ; Load address of PrintNum
    JSRR R6

FINISH_CALC
    ; Restore Registers
    LD R0, CALC_SAVE_R0
    LD R1, CALC_SAVE_R1
    LD R7, CALC_SAVE_R7
    RET

; --- Data & Constants ---
CALC_SAVE_R0    .FILL #0
CALC_SAVE_R1    .FILL #0
CALC_SAVE_R7    .FILL #0
CALC_OP_CHAR    .FILL #0

; Addresses of external subroutines
ADDR_MUL        .FILL x4000
ADDR_DIV        .FILL x4064
ADDR_EXP        .FILL x40C8
ADDR_PRINT_NUM  .FILL x4320

; Negative ASCII values for comparison
ASCII_PLUS_NEG  .FILL xFFD5 ; -43 ('+')
ASCII_MINUS_NEG .FILL xFFD3 ; -45 ('-')
ASCII_MUL_NEG   .FILL xFFD6 ; -42 ('*')
ASCII_DIV_NEG   .FILL xFFD1 ; -47 ('/')
ASCII_EXP_NEG   .FILL xFFA2 ; -94 ('^')

CHAR_NEWLINE    .FILL x000A
STR_EQUALS      .STRINGZ "="
STR_OP_PROMPT   .STRINGZ "Enter an arithmetic operation: "

.END