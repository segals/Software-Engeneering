;216214353
;328381926
.ORIG x4320

PrintNum
    ; 1. Save registers
    ST R0, PN_SAVE_R0
    ST R1, PN_SAVE_R1
    ST R2, PN_SAVE_R2
    ST R3, PN_SAVE_R3
    ST R4, PN_SAVE_R4
    ST R5, PN_SAVE_R5
    ST R6, PN_SAVE_R6 
    ST R7, PN_SAVE_R7

    ; Use R4 as pointer instead of R6
    LEA R4, DIGIT_STACK

    ; 2. Check edge case: 0
    ADD R0, R0, #0
    BRnp CHECK_SIGN
    LD R0, ASCII_ZERO
    OUT
    BR DONE

CHECK_SIGN
    ; 3. Handle sign
    BRzp POSITIVE_NUM
    
    ; --- Case: Negative Number ---
    LD R2, ASCII_MINUS
    ST R0, PN_TEMP      ; Save original negative number
    ADD R0, R2, #0
    OUT                 ; Print '-'
    
    ; --- SPECIAL CHECK FOR -32768 (x8000) ---
    ; -32768 cannot be negated to positive in 16-bit.
    ; We check if Number == x8000.
    LD R0, PN_TEMP      ; Reload the number
    LD R2, VAL_MIN_16   ; Load x8000
    
    ; Check if R0 == x8000. 
    ; Trick: x8000 + x8000 = 0 (overflows to 0 in 16-bit)
    ADD R2, R0, R2      
    BRz PRINT_MIN_INT   ; If result is 0, the number was x8000

    ; --- Normal Negative Number ---
    LD R0, PN_TEMP
    NOT R0, R0
    ADD R0, R0, #1      ; Make positive
    BR POSITIVE_NUM

PRINT_MIN_INT
    ; Manually print "32768" because we can't convert it to positive
    LEA R0, STR_32768
    PUTS
    BR DONE

POSITIVE_NUM
    LD R1, NUM_TEN

EXTRACT_LOOP
    ; Call Div
    LD R5, DIV_PTR      
    JSRR R5

    ; Convert to ASCII
    LD R5, ASCII_OFFSET 
    ADD R3, R3, R5

    ; Store in local stack
    STR R3, R4, #0
    ADD R4, R4, #1      

    ; Update number
    ADD R0, R2, #0
    BRp EXTRACT_LOOP

PRINT_LOOP
    ; Check if stack is empty
    LEA R5, DIGIT_STACK 
    NOT R5, R5
    ADD R5, R5, #1      
    ADD R5, R4, R5      
    BRz DONE            

    ; Pop and print
    ADD R4, R4, #-1     
    LDR R0, R4, #0      
    OUT                 
    BR PRINT_LOOP

DONE
    ; Restore registers
    LD R0, PN_SAVE_R0
    LD R1, PN_SAVE_R1
    LD R2, PN_SAVE_R2
    LD R3, PN_SAVE_R3
    LD R4, PN_SAVE_R4
    LD R5, PN_SAVE_R5
    LD R6, PN_SAVE_R6
    LD R7, PN_SAVE_R7
    RET

; --- Variables ---
DIV_PTR      .FILL x4064
NUM_TEN      .FILL #10
ASCII_ZERO   .FILL x30
ASCII_OFFSET .FILL x30
ASCII_MINUS  .FILL x2D
PN_TEMP      .FILL #0
VAL_MIN_16   .FILL x8000      ; The problematic number (-32768)
STR_32768    .STRINGZ "32768" ; String for the special case

; Register Storage
PN_SAVE_R0   .FILL #0
PN_SAVE_R1   .FILL #0
PN_SAVE_R2   .FILL #0
PN_SAVE_R3   .FILL #0
PN_SAVE_R4   .FILL #0
PN_SAVE_R5   .FILL #0
PN_SAVE_R6   .FILL #0
PN_SAVE_R7   .FILL #0

DIGIT_STACK  .BLKW #10

.END