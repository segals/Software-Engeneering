;216214353
;328381926
.ORIG x3000

    ; --- Get First Number ---
    LD R6, PTR_GETNUM       ; Load address of GetNum (x41F4)
    JSRR R6                 ; Call GetNum. Result returns in R2.
    
    ADD R4, R2, #0          ; Save the first number in R4 (backup)

    ; --- Get Second Number ---
    LD R6, PTR_GETNUM       ; Reload address of GetNum
    JSRR R6                 ; Call GetNum. Result returns in R2.
    
    ; --- Prepare Arguments for Calculator ---
    ; Calculator expects: R0 = Number A, R1 = Number B
    ADD R0, R4, #0          ; Move first number (from R4) to R0
    ADD R1, R2, #0          ; Move second number (from R2) to R1

    ; --- Calculate and Print ---
    LD R6, PTR_CALC         ; Load address of Calculator (x4384)
    JSRR R6                 ; Call Calculator

    HALT

PTR_GETNUM  .FILL x41F4     ; Address of GetNum subroutine
PTR_CALC    .FILL x4384     ; Address of Calculator subroutine

.END