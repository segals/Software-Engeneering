;216214353
;328381926
.ORIG x4064

Div
    ST R0, DIV_R0_SAVE  ; Save R0 to restore later
    ST R1, DIV_R1_SAVE  ; Save R1 to restore later
    ST R4, DIV_R4_SAVE  ; Save R4 to restore later
    ST R5, DIV_R5_SAVE  ; Save R5 to restore later
    ST R7, DIV_R7_SAVE  ; Save Return Address (R7)

    LD R1, DIV_R1_SAVE  ; Reload Divisor (R1)
    BRz ERROR_DIV_ZERO  ; If Divisor is 0, jump to error handling

    AND R2, R2, #0      ; Initialize Quotient (R2) to 0

    LD R3, DIV_R0_SAVE  ; Load Dividend into R3
    BRzp ABS_DIVIDEND   ; If positive, skip sign flip
    NOT R3, R3          ; Flip bits of R3
    ADD R3, R3, #1      ; Add 1 (R3 = |Dividend|)
ABS_DIVIDEND

    LD R4, DIV_R1_SAVE  ; Load Divisor into R4
    BRzp ABS_DIVISOR    ; If positive, skip sign flip
    NOT R4, R4          ; Flip bits of R4
    ADD R4, R4, #1      ; Add 1 (R4 = |Divisor|)
ABS_DIVISOR
    NOT R4, R4          ; Flip bits of |Divisor|
    ADD R4, R4, #1      ; R4 = -|Divisor| (Prepare for subtraction loop)

DIV_LOOP
    ADD R5, R3, R4      ; R5 = Remainder - |Divisor|
    BRn DIV_DONE        ; If result is negative, division is complete

    ADD R3, R5, #0      ; Update Remainder (R3) with new value
    ADD R2, R2, #1      ; Increment Quotient (R2)
    BR DIV_LOOP         ; Repeat loop

DIV_DONE
    ; R3 is already positive here (Result of |R0| % |R1|)
    ; No sign correction needed for Remainder per request

    AND R5, R5, #0      ; Clear temp register R5 (Sign Flag)

    LD R0, DIV_R0_SAVE  ; Load original Dividend
    BRzp SKIP_R0_NEG    ; If positive, skip
    ADD R5, R5, #1      ; Set flag R5=1 (Dividend was negative)
SKIP_R0_NEG

    LD R1, DIV_R1_SAVE  ; Load original Divisor
    BRzp SKIP_R1_NEG    ; If positive, skip
    ADD R5, R5, #-1     ; Subtract 1 from flag (Divisor was negative)
SKIP_R1_NEG

    ADD R5, R5, #0      ; Check flag value
    BRz FINISH          ; If 0 (Signs matched), Quotient is correct (Positive)

    NOT R2, R2          ; Flip Quotient bits
    ADD R2, R2, #1      ; Add 1 (Make Quotient negative)
    BR FINISH           ; Go to finish

ERROR_DIV_ZERO
    AND R2, R2, #0      ; Clear Quotient
    ADD R2, R2, #-1     ; Set Quotient to -1
    AND R3, R3, #0      ; Clear Remainder
    ADD R3, R3, #-1     ; Set Remainder to -1

FINISH
    LD R0, DIV_R0_SAVE  ; Restore R0
    LD R1, DIV_R1_SAVE  ; Restore R1
    LD R4, DIV_R4_SAVE  ; Restore R4
    LD R5, DIV_R5_SAVE  ; Restore R5
    LD R7, DIV_R7_SAVE  ; Restore R7
    RET                 ; Return from subroutine

DIV_R0_SAVE .fill #0    ; Storage for R0
DIV_R1_SAVE .fill #0    ; Storage for R1
DIV_R4_SAVE .fill #0    ; Storage for R4
DIV_R5_SAVE .fill #0    ; Storage for R5
DIV_R7_SAVE .fill #0    ; Storage for R7

.END